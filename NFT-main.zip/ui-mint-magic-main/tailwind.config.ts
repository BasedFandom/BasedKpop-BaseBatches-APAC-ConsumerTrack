
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			fontFamily: {
				mono: ['Roboto Mono', 'monospace'],
				display: ['Orbitron', 'sans-serif'],
			},
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				},
				kpop: {
					'bg-dark': '#111111',
					'metallic': '#c0c0c0',
					'metallic-dark': '#909090',
					'glow': '#75fff4',
					'button-start': '#75fff4',
					'button-end': '#ff75c8',
				}
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'shimmer': {
					'0%': { transform: 'translateX(-100%) rotate(30deg)' },
					'100%': { transform: 'translateX(100%) rotate(30deg)' }
				},
				'pulse-glow': {
					'0%, 100%': { 
                      opacity: '1',
                      boxShadow: '0 0 5px rgba(117, 255, 244, 0.5)'
                    },
					'50%': { 
                      opacity: '0.7',
                      boxShadow: '0 0 15px rgba(117, 255, 244, 0.8)'
                    }
				},
				'loading-dots': {
					'0%, 100%': { 
                      opacity: '0.2',
                      transform: 'scale(0.8)'
                    },
					'50%': { 
                      opacity: '1',
                      transform: 'scale(1)'
                    }
				},
				'wavy-background': {
					'0%': { backgroundPosition: '0% 0%' },
					'100%': { backgroundPosition: '100% 100%' }
				},
                'metal-shine': {
                    '0%': { backgroundPosition: '-200% 0' },
                    '100%': { backgroundPosition: '200% 0' }
                }
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'shimmer': 'shimmer 6s infinite linear',
				'pulse-glow': 'pulse-glow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
				'loading-dots': 'loading-dots 1.4s infinite ease-in-out',
				'wavy-background': 'wavy-background 15s ease infinite alternate',
                'metal-shine': 'metal-shine 2s linear infinite'
			},
			backgroundImage: {
				'metallic-gradient': 'linear-gradient(to bottom, #e0e0e0, #b0b0b0, #909090)',
                'metallic-shine': 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
				'dark-liquid': 'url("/public/noise-texture.png"), radial-gradient(ellipse at center, #222222 0%, #111111 70%, #000000 100%)',
				'button-gradient': 'linear-gradient(to right, #75fff4, #ff75c8)',
			},
			boxShadow: {
				'glow': '0 0 15px 2px rgba(117, 255, 244, 0.5)',
				'pink-glow': '0 0 15px 2px rgba(255, 117, 200, 0.5)',
				'turquoise-glow': '0 0 15px 2px rgba(117, 255, 244, 0.5)',
                'metallic': '0 1px 3px rgba(0,0,0,0.3), inset 0 1px 1px rgba(255,255,255,0.4)'
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
