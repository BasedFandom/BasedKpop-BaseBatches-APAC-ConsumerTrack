
-- Create a table for NFT mints
CREATE TABLE IF NOT EXISTS public.nft_mints (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id),
  name TEXT NOT NULL,
  mbti TEXT NOT NULL,
  birthday TEXT NOT NULL,
  bias TEXT NOT NULL,
  image_url TEXT,
  transaction_hash TEXT,
  status TEXT DEFAULT 'minted' CHECK (status IN ('pending', 'minted', 'failed')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE public.nft_mints ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to view their own NFTs
CREATE POLICY "Users can view their own NFTs" 
ON public.nft_mints 
FOR SELECT 
USING (auth.uid() = user_id);

-- Allow authenticated users to insert their own NFTs
CREATE POLICY "Users can create their own NFTs" 
ON public.nft_mints 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Public view for all NFTs (optional)
CREATE POLICY "Public can view all NFTs" 
ON public.nft_mints 
FOR SELECT 
USING (true);

-- Create a function to update timestamps
CREATE OR REPLACE FUNCTION public.update_nft_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger for the updated_at timestamp
CREATE TRIGGER update_nft_mints_timestamp
BEFORE UPDATE ON public.nft_mints
FOR EACH ROW
EXECUTE FUNCTION public.update_nft_timestamp();

