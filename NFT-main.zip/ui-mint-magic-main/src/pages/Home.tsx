
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoadingDots from '@/components/LoadingDots';
import KpopCassette from '@/components/KpopCassette';
import { useToast } from '@/components/ui/use-toast';
import GradientButton from '@/components/GradientButton';
import { useKpopId } from '@/hooks/useKpopId';

const Home: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { idData, mintedNfts, fetchMintedNfts } = useKpopId();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch user's minted NFTs
    fetchMintedNfts();
    
    // Simulate loading for a better UX
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timeout);
  }, [fetchMintedNfts]);

  useEffect(() => {
    // Welcome toast message when the app loads
    toast({
      title: "Welcome to KPOP ID NFT",
      description: "Create your own K-POP ID card and mint it as an NFT",
    });
  }, [toast]);

  const goToCreate = () => {
    navigate('/create');
  };
  
  const goToMint = () => {
    navigate('/mint');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex flex-col justify-center items-center p-4">
        {loading ? (
          <>
            <KpopCassette />
            <div className="mt-8 text-center">
              <div className="text-2xl font-display uppercase tracking-widest mb-4 text-white">
                LOADING YOUR BASED KPOP ID CARD
              </div>
              <div className="flex justify-center mt-2">
                <span className="mr-2 text-xs">...</span>
                <LoadingDots />
              </div>
            </div>
          </>
        ) : (
          <>
            <KpopCassette />
            <div className="mt-8 text-center w-full max-w-md">
              {idData && !mintedNfts.some(nft => nft.name === idData.name) && (
                <GradientButton 
                  onClick={goToMint}
                  className="w-full max-w-xs mx-auto mb-4"
                >
                  CONTINUE MINTING
                </GradientButton>
              )}
              
              <GradientButton 
                onClick={goToCreate}
                className="mx-auto mt-4 w-full max-w-xs"
              >
                CREATE NEW ID
              </GradientButton>
            </div>
          </>
        )}
      </div>
      
      <div className="mt-24 w-full max-w-5xl mx-auto">
        <div className="grid grid-cols-5 gap-4">
          <div className="col-span-1">
            <div className="text-sm font-bold text-gray-400 rotate-90 tracking-widest">KPOP</div>
          </div>
          <div className="col-span-3 flex justify-center space-x-8">
            <div className="text-center">
              <div className="border border-gray-700 rounded p-1 mb-1 bg-black/30">
                <div className="text-[8px] text-gray-500 uppercase">BASED KPOP ID N*.ORIG</div>
                <div className="text-[8px] text-gray-500 uppercase">FOR KPOP</div>
              </div>
            </div>
            <div className="text-center">
              <div className="border border-gray-700 rounded p-1 mb-1 bg-black/30">
                <div className="text-[8px] text-gray-500 uppercase">FROM EARTH WITH LOVE</div>
              </div>
            </div>
          </div>
          <div className="col-span-1 flex justify-end">
            <div className="text-sm font-bold text-gray-400">BASED KPOP</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
