
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import GradientButton from "@/components/GradientButton";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-kpop-bg-dark p-4">
      <div className="text-center">
        <h1 className="text-5xl font-display tracking-widest mb-4">404</h1>
        <p className="text-xl text-kpop-metallic mb-8">This page doesn't exist</p>
        <GradientButton onClick={() => window.location.href = "/"}>
          RETURN HOME
        </GradientButton>
      </div>
    </div>
  );
};

export default NotFound;
