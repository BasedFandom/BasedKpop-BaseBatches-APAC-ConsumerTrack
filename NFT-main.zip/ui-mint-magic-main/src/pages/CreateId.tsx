
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import KpopIdCard from '@/components/KpopIdCard';
import GradientButton from '@/components/GradientButton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Camera, Upload } from 'lucide-react';
import { useKpopId } from '@/hooks/useKpopId';

const CreateId: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { idData, saveIdData } = useKpopId();
  
  const [name, setName] = useState(idData?.name || '');
  const [mbti, setMbti] = useState(idData?.mbti || '');
  const [birthday, setBirthday] = useState(idData?.birthday || '');
  const [bias, setBias] = useState(idData?.bias || '');
  const [photo, setPhoto] = useState<string | null>(idData?.photo || null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please upload an image smaller than 5MB",
          variant: "destructive",
        });
        return;
      }
      
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setPhoto(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Form validation
    if (!name || !mbti || !birthday || !bias) {
      toast({
        title: "Missing Information",
        description: "Please fill out all fields to continue",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }
    
    if (!photo) {
      toast({
        title: "Missing Photo",
        description: "Please upload a photo for your ID card",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }
    
    // Validate MBTI format (should be 4 letters)
    if (mbti.length !== 4) {
      toast({
        title: "Invalid MBTI",
        description: "MBTI should be 4 letters (e.g., INFP, ESTP)",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }
    
    // Birthday format validation (simple check)
    const birthdayPattern = /^\d{4}\/\d{2}\/\d{2}$/;
    if (!birthdayPattern.test(birthday)) {
      toast({
        title: "Invalid Birthday Format",
        description: "Please use YYYY/MM/DD format",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }
    
    // Save the data
    const idData = { name, mbti, birthday, bias, photo };
    saveIdData(idData);
    
    // Show success message
    toast({
      title: "ID Card Created",
      description: "Your K-POP ID card is ready to mint!",
    });
    
    // Navigate to mint page
    setTimeout(() => {
      setIsSubmitting(false);
      navigate('/mint');
    }, 500);
  };
  
  // Handle camera click to trigger file input
  const handleCameraClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-display tracking-widest mb-8 text-center">CREATE YOUR KPOP ID</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
        <div className="order-2 lg:order-1">
          <KpopIdCard 
            name={name}
            mbti={mbti}
            birthday={birthday}
            bias={bias}
            photo={photo}
          />
        </div>
        
        <div className="order-1 lg:order-2">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="photo" className="font-mono text-kpop-metallic block mb-2">
                  ■ PHOTO
                </Label>
                <div className="relative">
                  <Input 
                    id="photo"
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    className="hidden"
                  />
                  <div 
                    className="border border-kpop-metallic p-4 rounded-md flex items-center justify-center cursor-pointer hover:bg-white/5 transition-colors"
                    onClick={handleCameraClick}
                  >
                    <div className="flex flex-col items-center text-center">
                      {photo ? (
                        <div className="flex items-center space-x-2">
                          <Camera className="text-kpop-glow" size={24} />
                          <span>Change photo</span>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                          <Upload className="mb-2 text-kpop-glow" size={32} />
                          <span>Click to upload your photo</span>
                          <span className="text-xs text-muted-foreground mt-1">JPG, PNG or GIF, max 5MB</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="name" className="font-mono text-kpop-metallic block mb-2">
                  ■ NAME
                </Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="font-mono bg-muted border-kpop-metallic text-white"
                  placeholder="Your name"
                  maxLength={20}
                />
              </div>
              
              <div>
                <Label htmlFor="mbti" className="font-mono text-kpop-metallic block mb-2">
                  ■ MBTI
                </Label>
                <Input
                  id="mbti"
                  value={mbti}
                  onChange={(e) => setMbti(e.target.value.toUpperCase())}
                  className="font-mono bg-muted border-kpop-metallic text-white uppercase"
                  placeholder="INFP, ESTP, etc."
                  maxLength={4}
                />
              </div>
              
              <div>
                <Label htmlFor="birthday" className="font-mono text-kpop-metallic block mb-2">
                  ■ B-DAY
                </Label>
                <Input
                  id="birthday"
                  value={birthday}
                  onChange={(e) => setBirthday(e.target.value)}
                  className="font-mono bg-muted border-kpop-metallic text-white"
                  placeholder="YYYY/MM/DD"
                  maxLength={10}
                />
              </div>
              
              <div>
                <Label htmlFor="bias" className="font-mono text-kpop-metallic block mb-2">
                  ■ ULT BIAS
                </Label>
                <Input
                  id="bias"
                  value={bias}
                  onChange={(e) => setBias(e.target.value)}
                  className="font-mono bg-muted border-kpop-metallic text-white"
                  placeholder="Your ultimate bias"
                  maxLength={20}
                />
              </div>
            </div>
            
            <GradientButton type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? 'SAVING...' : 'CONTINUE'}
            </GradientButton>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateId;
