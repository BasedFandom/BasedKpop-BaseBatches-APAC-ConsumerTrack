
import React from 'react';
import Footer from '@/components/Footer';
import { Link, Outlet, useLocation } from 'react-router-dom';

const Index: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-4 px-6 flex justify-between items-center border-b border-gray-800">
        <Link to="/" className="flex items-center">
          <div className="w-10 h-10 rounded-full border-2 border-gray-600 overflow-hidden flex items-center justify-center bg-gradient-to-b from-gray-700 to-gray-900">
            <span className="text-blue-400 font-bold">K</span>
          </div>
        </Link>
        
        <nav className="hidden sm:flex space-x-6">
          <Link 
            to="/" 
            className={`font-mono text-xs uppercase tracking-wider transition-colors ${isActive('/') ? 'text-white' : 'text-gray-500 hover:text-white'}`}
          >
            HOME
          </Link>
          <Link 
            to="/create" 
            className={`font-mono text-xs uppercase tracking-wider transition-colors ${isActive('/create') ? 'text-white' : 'text-gray-500 hover:text-white'}`}
          >
            CREATE ID
          </Link>
          <Link 
            to="/collection" 
            className={`font-mono text-xs uppercase tracking-wider transition-colors ${isActive('/collection') ? 'text-white' : 'text-gray-500 hover:text-white'}`}
          >
            MY COLLECTION
          </Link>
        </nav>
        
        <div className="text-gray-500 text-xs uppercase tracking-wider font-mono">
          Contact us @based_kpop
        </div>
      </header>
      
      <main className="flex-1">
        <Outlet />
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
