
import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import ShareModal from '@/components/ShareModal';
import LoadingDots from '@/components/LoadingDots';
import { useKpopId } from '@/hooks/useKpopId';
import html2canvas from 'html2canvas';
import { useActiveWallet } from "thirdweb/react";
import IdCardDisplay from '@/components/IdCardDisplay';
import WalletSection from '@/components/WalletSection';
import PaymentSection from '@/components/PaymentSection';
import PageDecorator from '@/components/PageDecorator';

const MintId: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { 
    idData, 
    minting, 
    minted, 
    mintIdCard,
  } = useKpopId();
  
  const [shareOpen, setShareOpen] = useState(false);
  const [cardImage, setCardImage] = useState<string | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const activeWallet = useActiveWallet();
  const [walletConnected, setWalletConnected] = useState(false);

  useEffect(() => {
    if (!idData) {
      toast({
        title: "No ID Data Found",
        description: "Please create your ID card first",
        variant: "destructive",
      });
      navigate('/create');
    }
  }, [idData, navigate, toast]);
  
  // Check if wallet is connected
  useEffect(() => {
    const checkWalletConnection = async () => {
      if (activeWallet) {
        try {
          const account = activeWallet.getAccount();
          setWalletConnected(!!account?.address);
        } catch (error) {
          console.error("Error checking wallet connection:", error);
          setWalletConnected(false);
        }
      } else {
        setWalletConnected(false);
      }
    };
    
    checkWalletConnection();
  }, [activeWallet]);

  const captureCard = async () => {
    if (!cardRef.current) return null;
    
    try {
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: null,
        scale: 2,
        logging: false,
        useCORS: true,
        allowTaint: true,
      });
      return canvas.toDataURL('image/png');
    } catch (error) {
      console.error('Error capturing card:', error);
      return null;
    }
  };

  const handleMint = async () => {
    try {
      // Capture the card as an image first
      const imageUrl = await captureCard();
      if (!imageUrl) {
        toast({
          title: "Error",
          description: "Failed to capture your ID card image",
          variant: "destructive",
        });
        return;
      }
      
      setCardImage(imageUrl);
      
      if (walletConnected) {
        // If wallet is connected, show payment interface
        setShowPayment(true);
      } else {
        // Otherwise use the mock mint process
        const success = await mintIdCard(imageUrl);
        
        if (success) {
          // Animation effect for minting success
          animateCardSuccess();
        }
      }
    } catch (error) {
      console.error('Mint process error:', error);
      toast({
        title: "Minting Failed",
        description: "There was an unexpected error",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    if (!cardImage) {
      const imageUrl = await captureCard();
      if (imageUrl) {
        setCardImage(imageUrl);
      }
    }
    setShareOpen(true);
  };
  
  const handlePaymentSuccess = () => {
    setShowPayment(false);
    animateCardSuccess();
  };

  const animateCardSuccess = () => {
    const cardElement = cardRef.current;
    if (cardElement) {
      cardElement.classList.add('scale-110');
      setTimeout(() => {
        cardElement.classList.remove('scale-110');
      }, 800);
    }
  };

  if (!idData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingDots />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 flex flex-col items-center justify-center min-h-screen">
      <IdCardDisplay
        ref={cardRef}
        name={idData.name}
        mbti={idData.mbti}
        birthday={idData.birthday}
        bias={idData.bias}
        photo={idData.photo}
        className="mb-8"
      />
      
      {showPayment && cardImage ? (
        <PaymentSection 
          cardImage={cardImage}
          name={idData.name}
          mbti={idData.mbti}
          onSuccess={handlePaymentSuccess}
          onCancel={() => setShowPayment(false)}
        />
      ) : (
        <WalletSection
          walletConnected={walletConnected}
          minted={minted}
          minting={minting}
          onMint={handleMint}
          onShare={handleShare}
          onWalletConnect={() => setWalletConnected(true)}
        />
      )}
      
      <PageDecorator />
      
      <ShareModal 
        open={shareOpen}
        onOpenChange={setShareOpen}
        imageUrl={cardImage}
      />
    </div>
  );
};

export default MintId;
