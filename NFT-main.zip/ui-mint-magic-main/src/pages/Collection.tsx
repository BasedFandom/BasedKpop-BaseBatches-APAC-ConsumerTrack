
import React from 'react';
import { useNavigate } from 'react-router-dom';
import GradientButton from '@/components/GradientButton';
import NftCollection from '@/components/NftCollection';

const Collection: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-display tracking-widest mb-8 text-center">MY NFT COLLECTION</h1>
      
      <div className="mb-6 flex justify-center">
        <GradientButton onClick={() => navigate('/create')} className="mx-2">
          CREATE NEW ID
        </GradientButton>
      </div>
      
      <NftCollection />
    </div>
  );
};

export default Collection;
