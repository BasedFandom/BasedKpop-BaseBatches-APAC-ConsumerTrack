
export interface KpopIdData {
  name: string;
  mbti: string;
  birthday: string;
  bias: string;
  photo: string | null;
}

export interface NftMint {
  id: string;
  user_id: string;
  name: string;
  mbti: string;
  birthday: string;
  bias: string;
  image_url: string;
  transaction_hash?: string;
  status: 'pending' | 'minted' | 'failed';
  created_at: string;
}
