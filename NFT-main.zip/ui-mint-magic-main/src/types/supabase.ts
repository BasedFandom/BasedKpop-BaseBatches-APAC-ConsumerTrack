
export interface NftMintsTable {
  id: string;
  user_id: string;
  name: string;
  mbti: string;
  birthday: string;
  bias: string;
  image_url: string;
  transaction_hash?: string;
  status: 'pending' | 'minted' | 'failed';
  created_at: string;
  updated_at: string;
}

export interface Database {
  public: {
    Tables: {
      nft_mints: {
        Row: NftMintsTable;
        Insert: Omit<NftMintsTable, 'id' | 'updated_at'> & { id?: string, updated_at?: string };
        Update: Partial<NftMintsTable>;
      };
    };
  };
}
