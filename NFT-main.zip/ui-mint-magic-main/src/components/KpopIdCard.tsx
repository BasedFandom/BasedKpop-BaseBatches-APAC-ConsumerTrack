
import React from 'react';
import MetallicFrame from './MetallicFrame';

interface KpopIdCardProps {
  name: string;
  mbti: string;
  birthday: string;
  bias: string;
  photo: string | null;
}

const KpopIdCard: React.FC<KpopIdCardProps> = ({ name, mbti, birthday, bias, photo }) => {
  return (
    <MetallicFrame className="w-full max-w-md mx-auto">
      <div className="bg-gradient-to-b from-[#c5c5c5] to-[#b0b0b0] p-4 rounded text-black">
        {/* Header with title and hash marks */}
        <div className="flex justify-between items-center mb-5">
          <div className="text-2xl font-display tracking-wider font-black italic text-black">KPOP ID</div>
          <div className="flex">
            <div className="text-black opacity-80 text-xs tracking-widest">////////////////////</div>
            <div className="ml-2 size-5 rounded-full border border-black/50 flex items-center justify-center">
              <div className="size-3 bg-black/10 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-[120px_1fr] gap-5">
          {/* Photo area with grid lines */}
          <div className="relative">
            <div className="relative border-2 border-black/40 rounded-sm overflow-hidden h-32 w-full bg-black/20 flex items-center justify-center">
              {photo ? (
                <div className="relative z-10 w-full h-full">
                  <img src={photo} alt="User" className="w-full h-full object-cover" />
                  {/* Overlay to blend with metallic look */}
                  <div className="absolute inset-0 bg-black/10 mix-blend-overlay"></div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-black/70 font-mono text-sm">
                  PHOTO
                </div>
              )}
              
              {/* Star accent in corner */}
              <div className="absolute top-1 left-1 text-xs text-white">✦</div>
              <div className="absolute top-3 left-3 text-[8px] text-white">✦</div>
            </div>
            
            {/* Grid lines overlay */}
            <div className="absolute inset-0 pointer-events-none">
              {/* Horizontal grid lines */}
              {[...Array(6)].map((_, i) => (
                <div key={`h-${i}`} className="absolute w-full h-px bg-black/10" style={{ top: `${(i + 1) * 16}%` }}></div>
              ))}
              {/* Vertical grid lines */}
              {[...Array(6)].map((_, i) => (
                <div key={`v-${i}`} className="absolute h-full w-px bg-black/10" style={{ left: `${(i + 1) * 16}%` }}></div>
              ))}
            </div>
          </div>
          
          {/* Information fields */}
          <div className="space-y-2 font-mono text-sm">
            <div>
              <div className="text-black mb-1 flex items-center">
                <span className="mr-1 text-black">■</span> NAME:
              </div>
              <div className="pl-6 font-mono tracking-wider text-black/90">{name || 'XXXX XXXXX'}</div>
            </div>
            <div>
              <div className="text-black mb-1 flex items-center">
                <span className="mr-1 text-black">■</span> MBTI:
              </div>
              <div className="pl-6 font-mono tracking-wider text-black/90">{mbti || 'XXXX'}</div>
            </div>
            <div>
              <div className="text-black mb-1 flex items-center">
                <span className="mr-1 text-black">■</span> B-DAY:
              </div>
              <div className="pl-6 font-mono tracking-wider text-black/90">{birthday || 'XXXX/XX/XX'}</div>
            </div>
            <div>
              <div className="text-black mb-1 flex items-center">
                <span className="mr-1 text-black">■</span> ULT BIAS:
              </div>
              <div className="pl-6 font-mono tracking-wider text-black/90">{bias || 'XXXXXXXXXXXXXXXX'}</div>
            </div>
          </div>
        </div>
      </div>
    </MetallicFrame>
  );
};

export default KpopIdCard;
