
import React from 'react';

const PageDecorator: React.FC = () => {
  return (
    <div className="mt-32 w-full max-w-5xl">
      <div className="grid grid-cols-5 gap-4">
        <div className="col-span-1">
          <img src="/public/based-kpop-logo.png" alt="Based KPOP ID" className="w-16 opacity-70" />
        </div>
        <div className="col-span-3 flex justify-center space-x-8">
          <div className="text-center">
            <div className="border border-gray-700 rounded p-2 mb-1 bg-black/30">
              <div className="text-[8px] text-gray-500 uppercase">BASED KPOP ID N*.ORIG</div>
              <div className="text-[8px] text-gray-500 uppercase">FOR KPOP</div>
              <div className="h-4 w-8 mx-auto border border-gray-700 flex items-center justify-center mt-1">
                <span className="text-[8px] text-gray-500">ND</span>
              </div>
              <div className="text-[6px] text-gray-600 mt-1">© COPYRIGHT. ALL RIGHTS RESERVED</div>
              <div className="border-t border-gray-700 mt-1 pt-1">
                <div className="flex justify-between">
                  <div className="text-[5px] text-gray-600">WEIGHT: 0.0G</div>
                  <div className="text-[5px] text-gray-600">MADE IN WEB</div>
                </div>
              </div>
            </div>
          </div>
          <div className="text-center">
            <div className="border border-gray-700 rounded p-2 mb-1 bg-black/30">
              <div className="text-[8px] text-gray-500 uppercase">BASED KPOP ID</div>
              <div className="h-6 flex justify-center items-center mt-1">
                <div className="border border-gray-700 p-1">
                  <div className="grid grid-cols-3 gap-1">
                    {Array(9).fill(0).map((_, i) => (
                      <div key={i} className="w-1 h-2 bg-gray-700"></div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="text-[6px] text-gray-600 mt-1">FROM EARTH WITH LOVE</div>
            </div>
          </div>
        </div>
        <div className="col-span-1 flex justify-end">
          <div className="text-right">
            <div className="text-sm font-bold text-gray-400 rotate-90 tracking-widest">KPOP</div>
            <div className="text-sm font-bold text-gray-400 mt-1">BASED KPOP</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PageDecorator;
