
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-6 mt-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center items-center gap-6 mb-6">
          <div className="flex flex-col items-center">
            <div className="text-xs text-kpop-metallic mb-1">BASED KPOP ID №.ORIG</div>
            <div className="text-xs text-kpop-metallic">FOR K-POP</div>
            <div className="flex mt-2">
              <div className="w-6 h-6 border border-kpop-metallic flex items-center justify-center text-xs">№</div>
              <div className="w-6 h-6 border border-kpop-metallic flex items-center justify-center text-xs">D</div>
            </div>
          </div>
          
          <div className="flex flex-col items-center text-xs text-kpop-metallic">
            <div>© COPYRIGHT. ALL RIGHTS RESERVED</div>
            <div className="max-w-[140px] text-center opacity-70 text-[8px] mt-1">
              ALL RIGHTS RESERVED. NO PART OF THIS PUBLICATION MAY BE REPRODUCED, DISTRIBUTED, OR TRANSMITTED IN ANY FORM.
            </div>
            <div className="w-32 h-10 mt-2 border border-kpop-metallic flex items-center justify-center">
              <div className="transform -rotate-90 text-[8px]">{'>'}{'>'}{'>'}{'>'}{'>'}{'>'}{'>'}{'>'}{'>'}{'>'}</div>
            </div>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="text-xs text-kpop-metallic mb-1">BASED KPOP ID™</div>
            <div className="text-[10px] text-kpop-metallic/70">PRODUCT KEY</div>
            <div className="grid grid-cols-4 gap-[2px] mt-1 text-[8px] text-kpop-metallic/70">
              <div>DATA</div>
              <div>01B</div>
              <div>WAVE</div>
              <div>01B</div>
              <div>NAME</div>
              <div>01B</div>
              <div>NAME</div>
              <div>01B</div>
              <div>NAME</div>
              <div>01B</div>
              <div>NAME</div>
              <div>01B</div>
            </div>
            <div className="w-32 h-10 mt-2 border border-kpop-metallic flex items-center justify-center">
              <div className="text-[8px]">BASED KPOP ID</div>
            </div>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 border border-kpop-metallic rounded-full flex items-center justify-center mb-2">
              <div className="text-xs text-kpop-metallic">©</div>
            </div>
            <div className="text-xs text-kpop-metallic">365</div>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="w-20 h-16 border border-kpop-metallic flex items-center justify-center mb-2">
              <div className="w-12 h-8 border border-kpop-metallic rounded-full"></div>
            </div>
            <div className="text-xs text-kpop-metallic">FROM EARTH</div>
            <div className="text-xs text-kpop-metallic">FOR LOVE</div>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="text-3xl font-display text-kpop-metallic mb-1">KPOP</div>
            <div className="text-3xl font-display text-kpop-metallic">BASED KPOP</div>
          </div>
        </div>
        
        <div className="text-center text-xs text-kpop-metallic/50">
          <a href="#" className="hover:text-white transition-colors">Contact us @based_kpop</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
