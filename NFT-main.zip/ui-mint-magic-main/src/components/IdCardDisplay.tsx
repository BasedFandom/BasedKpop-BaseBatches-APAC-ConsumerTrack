
import React, { forwardRef } from 'react';
import KpopIdCard from '@/components/KpopIdCard';

interface IdCardDisplayProps {
  name: string;
  mbti: string;
  birthday: string;
  bias: string;
  photo: string | null;
  className?: string;
}

const IdCardDisplay = forwardRef<HTMLDivElement, IdCardDisplayProps>(
  ({ name, mbti, birthday, bias, photo, className }, ref) => {
    return (
      <div ref={ref} className={`transition-transform duration-700 ${className}`}>
        <KpopIdCard 
          name={name}
          mbti={mbti}
          birthday={birthday}
          bias={bias}
          photo={photo}
        />
      </div>
    );
  }
);

IdCardDisplay.displayName = 'IdCardDisplay';

export default IdCardDisplay;
