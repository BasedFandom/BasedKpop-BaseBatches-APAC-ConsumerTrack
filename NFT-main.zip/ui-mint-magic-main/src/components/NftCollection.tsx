
import React, { useEffect, useState } from 'react';
import { useKpopId } from '@/hooks/useKpopId';
import { useActiveWallet } from "thirdweb/react";
import LoadingDots from './LoadingDots';
import { client } from "../integrations/thirdweb/client";
import ConnectWalletPrompt from './ConnectWalletPrompt';
import EmptyNFTCollection from './EmptyNFTCollection';
import NFTCollectionGrid from './NFTCollectionGrid';
import { getContract, readContract } from "thirdweb";

const NftCollection: React.FC = () => {
  const { mintedNfts, fetchMintedNfts, loading: localLoading } = useKpopId();
  const activeWallet = useActiveWallet();
  const [isConnected, setIsConnected] = useState(false);
  const [onChainTokens, setOnChainTokens] = useState<any[]>([]);
  const [tokensLoading, setTokensLoading] = useState(false);
  
  // Fetch NFTs from Thirdweb when wallet is connected
  useEffect(() => {
    const fetchOnChainTokens = async () => {
      if (!activeWallet) return;
      
      const account = activeWallet.getAccount();
      if (!account || !account.address) return;
      
      try {
        setTokensLoading(true);
        
        // Get contract instance
        const contract = getContract({
          client,
          address: "0x9c38ed5bC072972dffC59bfaab6ADE77D3FC285B",
          chain: {
            id: 8453,
            name: "Base",
            rpc: "https://mainnet.base.org"
          }
        });

        // Get tokens owned by the wallet using readContract
        let tokens = [];
        try {
          // In ThirdWeb v5, use readContract instead of contract.read
          tokens = await readContract({
            contract,
            method: "tokensOfOwner",
            params: [account.address]
          });
        } catch (e) {
          console.error("Error fetching tokens:", e);
          // Fallback to empty array if token fetching fails
          tokens = [];
        }
        
        // Transform the response into the expected format
        setOnChainTokens(
          (tokens || []).map((token: any) => ({
            id: token.metadata?.id || "",
            name: token.metadata?.name || "KPOP ID",
            mbti: token.metadata?.attributes?.find((attr: any) => attr.trait_type === "MBTI")?.value || "XXXX",
            image_url: token.metadata?.image || "",
            created_at: new Date().toISOString()
          }))
        );
      } catch (error) {
        console.error("Error fetching on-chain NFTs:", error);
        setOnChainTokens([]);
      } finally {
        setTokensLoading(false);
      }
    };
    
    fetchOnChainTokens();
  }, [activeWallet]);
  
  useEffect(() => {
    fetchMintedNfts();
    const checkConnection = async () => {
      if (activeWallet) {
        try {
          const account = activeWallet.getAccount();
          setIsConnected(!!account?.address);
        } catch (error) {
          console.error("Error getting wallet address:", error);
          setIsConnected(false);
        }
      } else {
        setIsConnected(false);
      }
    };
    
    checkConnection();
  }, [fetchMintedNfts, activeWallet]);
  
  const loading = localLoading || tokensLoading;
  
  // Combine on-chain NFTs with locally stored ones
  const allNfts = [
    // Include on-chain NFTs if available
    ...onChainTokens,
    // Include local NFTs
    ...mintedNfts
  ];
  
  if (!isConnected) {
    return (
      <ConnectWalletPrompt 
        onConnect={() => setIsConnected(true)} 
        hasLocalNfts={mintedNfts.length > 0} 
        localNfts={mintedNfts} 
      />
    );
  }
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <LoadingDots />
      </div>
    );
  }
  
  if (allNfts.length === 0) {
    return <EmptyNFTCollection />;
  }
  
  // Get wallet address for display
  const walletAddress = activeWallet?.getAccount().address;
  
  return <NFTCollectionGrid nfts={allNfts} walletAddress={walletAddress} />;
};

export default NftCollection;
