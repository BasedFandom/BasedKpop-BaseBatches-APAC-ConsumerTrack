
import React, { useEffect, useState } from 'react';
import { PayEmbed, useActiveWallet } from "thirdweb/react";
import { prepareContractCall, sendTransaction } from "thirdweb";
import { client } from "../integrations/thirdweb/client";
import { useKpopId } from '@/hooks/useKpopId';
import { useToast } from '@/components/ui/use-toast';
import LoadingDots from './LoadingDots';

interface MintPayProps {
  imageUrl: string | null;
  name: string;
  mbti: string;
  onMintSuccess?: () => void;
}

const MintPay: React.FC<MintPayProps> = ({ imageUrl, name, mbti, onMintSuccess }) => {
  const activeWallet = useActiveWallet();
  const { toast } = useToast();
  const { mintIdCard } = useKpopId();
  const [signatureData, setSignatureData] = useState<null | {
    payload: any;
    signature: string;
  }>(null);
  const [loading, setLoading] = useState(false);

  const fetchSignature = async () => {
    if (!activeWallet || !imageUrl) return;
    
    // In ThirdWeb v5, wallet.address is accessed differently
    const walletAddress = activeWallet?.getAccount().address || "";
    if (!walletAddress) return;
    
    setLoading(true);
    try {
      // In a real implementation, this would call your backend API
      // For now, we'll mock the response for demonstration
      
      // Mock signature data for demonstration
      setTimeout(() => {
        const mockPayload = {
          to: walletAddress,
          quantity: BigInt(1),
          metadata: { name, mbti, image: imageUrl },
          pricePerToken: BigInt(7 * 1e6), // 7 USDC (6位小数)
          currency: "0xd9AA3A156c9E2e7Fc4b90CDd1CFFE45A731B1a14", // Base USDC 地址
          validityStartTimestamp: BigInt(Math.floor(Date.now() / 1000)),
          validityEndTimestamp: BigInt(Math.floor(Date.now() / 1000) + 3600),
          primarySaleRecipient: "0x123456789abcdef123456789abcdef123456789a", // Replace with your wallet
          uid: "0x" + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join(''),
        };

        const mockSignature = "0x" + Array(130).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
        
        setSignatureData({
          payload: mockPayload,
          signature: mockSignature
        });
        setLoading(false);
      }, 1500);
    } catch (error) {
      console.error("Error fetching signature:", error);
      toast({
        title: "Error",
        description: "Failed to fetch minting signature",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeWallet && activeWallet.getAccount().address && imageUrl) {
      fetchSignature();
    }
  }, [activeWallet, imageUrl]);

  const handlePaymentSuccess = async () => {
    // In a real implementation, you'd verify the transaction
    // For now, we'll simulate success and call the existing mintIdCard function
    if (imageUrl) {
      await mintIdCard(imageUrl);
    }
    
    if (onMintSuccess) {
      onMintSuccess();
    }
    
    toast({
      title: "NFT Minted!",
      description: "Your K-POP ID has been successfully minted",
    });
  };

  if (loading || !signatureData) {
    return (
      <div className="flex flex-col items-center justify-center p-4">
        <div className="text-center mb-4">Preparing payment...</div>
        <LoadingDots />
      </div>
    );
  }

  const nftMeta = {
    name: `BASED KPOP - ${name}`,
    image: imageUrl || "",
    description: `BASED KPOP ID for ${name} with MBTI: ${mbti}`,
  };

  // In Thirdweb v5, we need to use prepareContractCall correctly
  const preparedTransaction = prepareContractCall({
    contract: {
      client,
      address: "0x9c38ed5bC072972dffC59bfaab6ADE77D3FC285B", 
      chain: {
        id: 8453, // Base chain ID
        name: "Base",
        rpc: "https://mainnet.base.org"
      }
    },
    method: "mintWithSignature",
    params: [signatureData.payload, signatureData.signature],
  });

  return (
    <div className="mint-pay-container">
      <PayEmbed
        clientId={import.meta.env.VITE_THIRDWEB_CLIENT_ID || "YOUR_CLIENT_ID"}
        transaction={preparedTransaction}
        metadata={nftMeta}
        onComplete={handlePaymentSuccess}
      />
    </div>
  );
};

export default MintPay;
