
import React from 'react';
import MetallicFrame from './MetallicFrame';

const KpopCassette: React.FC = () => {
  return (
    <MetallicFrame className="w-full max-w-md mx-auto shadow-xl">
      <div className="bg-gradient-to-b from-[#c5c5c5] to-[#b0b0b0] p-6 rounded text-black">
        <div className="text-center mb-6">
          <h2 className="text-3xl font-display tracking-widest font-black italic text-black">BASED KPOP ID</h2>
        </div>
        
        {/* Cassette body */}
        <div className="flex justify-center mb-6">
          <div className="relative w-64 h-36 border-2 border-black/50 bg-gradient-to-b from-[#303030] to-[#101010] flex justify-center items-center rounded-sm overflow-hidden">
            {/* Cassette reel windows */}
            <div className="absolute left-10 top-1/2 transform -translate-y-1/2 w-12 h-12 rounded-full bg-[#101010] border-2 border-black/70 flex justify-center items-center">
              <div className="w-8 h-8 rounded-full bg-[#000000] border border-gray-800 flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
            <div className="absolute right-10 top-1/2 transform -translate-y-1/2 w-12 h-12 rounded-full bg-[#101010] border-2 border-black/70 flex justify-center items-center">
              <div className="w-8 h-8 rounded-full bg-[#000000] border border-gray-800 flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
            
            {/* Cassette center and counter */}
            <div className="absolute top-2 flex flex-col items-center">
              <div className="bg-black/70 rounded-sm px-3 py-1 mb-1">
                <div className="flex space-x-4">
                  <div className="text-[8px] text-white/70 font-mono">100</div>
                  <div className="text-[8px] text-white/70 font-mono">50</div>
                  <div className="text-[8px] text-white/70 font-mono">0</div>
                </div>
                <div className="h-1 w-full bg-gray-800 mt-0.5 flex items-center">
                  <div className="h-2 w-0.5 bg-white/70 transform translate-x-4"></div>
                </div>
              </div>
            </div>
            
            {/* Cassette tape line */}
            <div className="w-24 h-0.5 bg-black"></div>
            
            {/* Cassette holes */}
            <div className="absolute bottom-2 flex space-x-8">
              <div className="w-3 h-3 rounded-full bg-black"></div>
              <div className="w-3 h-3 rounded-full bg-black"></div>
              <div className="w-3 h-3 rounded-full bg-black"></div>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="flex justify-start mb-4">
          <div className="text-xs text-black/70 tracking-widest">////////////////////</div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="text-[10px] font-mono text-black/70">////////</div>
          <div className="w-8 h-8 rounded-full border border-black/50 flex justify-center items-center">
            <div className="w-6 h-6 rounded-full bg-black/10 flex items-center justify-center">
              <div className="w-5 h-5 rounded-full bg-gradient-to-r from-gray-300 to-gray-400"></div>
            </div>
          </div>
        </div>
        
        {/* Decorative globe icon */}
        <div className="absolute bottom-3 right-3 opacity-30">
          <div className="w-4 h-4 rounded-full border border-black"></div>
        </div>
      </div>
    </MetallicFrame>
  );
};

export default KpopCassette;
