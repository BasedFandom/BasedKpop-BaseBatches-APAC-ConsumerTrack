
import React from 'react';
import MintPay from '@/components/MintPay';
import GradientButton from '@/components/GradientButton';

interface PaymentSectionProps {
  cardImage: string | null;
  name: string;
  mbti: string;
  onSuccess: () => void;
  onCancel: () => void;
}

const PaymentSection: React.FC<PaymentSectionProps> = ({ 
  cardImage, 
  name, 
  mbti, 
  onSuccess, 
  onCancel 
}) => {
  return (
    <div className="mt-8 w-full max-w-md">
      <div className="bg-black/40 p-4 rounded-md border border-kpop-metallic mb-4">
        <h3 className="font-display text-lg mb-4 text-center">MINT YOUR NFT - 7 USDC</h3>
        {cardImage && (
          <MintPay 
            imageUrl={cardImage} 
            name={name}
            mbti={mbti}
            onMintSuccess={onSuccess}
          />
        )}
      </div>
      <GradientButton 
        onClick={onCancel}
        className="w-full mt-2"
        variant="mint"
      >
        CANCEL
      </GradientButton>
    </div>
  );
};

export default PaymentSection;
