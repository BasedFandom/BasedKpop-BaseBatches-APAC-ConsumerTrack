
import React from 'react';
import { ConnectEmbed } from "thirdweb/react";

interface WalletConnectProps {
  onConnect?: () => void;
}

const WalletConnect: React.FC<WalletConnectProps> = ({ onConnect }) => {
  return (
    <div className="wallet-connect-container">
      <ConnectEmbed 
        clientId={import.meta.env.VITE_THIRDWEB_CLIENT_ID || "YOUR_CLIENT_ID"}
        chain={{
          id: 8453, // Base chain ID
          name: "Base",
          rpc: "https://mainnet.base.org"
        }}
        onConnect={onConnect}
      />
    </div>
  );
};

export default WalletConnect;
