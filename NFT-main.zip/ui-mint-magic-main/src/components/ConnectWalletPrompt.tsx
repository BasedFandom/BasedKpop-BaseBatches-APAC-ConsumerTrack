
import React from 'react';
import WalletConnect from './WalletConnect';
import NFTCard from './NFTCard';

interface ConnectWalletPromptProps {
  onConnect: () => void;
  hasLocalNfts: boolean;
  localNfts: Array<any>;
}

const ConnectWalletPrompt: React.FC<ConnectWalletPromptProps> = ({ 
  onConnect, 
  hasLocalNfts, 
  localNfts 
}) => {
  return (
    <div className="py-6">
      <h2 className="text-2xl font-display tracking-widest mb-6 text-center">YOUR NFT COLLECTION</h2>
      <div className="text-center p-8 border border-kpop-metallic rounded-md mb-8">
        <div className="text-xl font-display tracking-widest mb-4">CONNECT YOUR WALLET</div>
        <p className="text-kpop-metallic-dark text-sm mb-6">
          Connect your wallet to see your on-chain NFT collection
        </p>
        <div className="max-w-xs mx-auto">
          <WalletConnect onConnect={onConnect} />
        </div>
      </div>
      
      {hasLocalNfts && <LocalNFTCollection nfts={localNfts} />}
    </div>
  );
};

const LocalNFTCollection: React.FC<{ nfts: Array<any> }> = ({ nfts }) => {
  if (nfts.length === 0) return null;
  
  return (
    <>
      <h3 className="text-xl font-display tracking-widest my-6 text-center">LOCAL COLLECTION</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {nfts.map((nft, index) => (
          <NFTCard key={`local-${index}`} nft={nft} />
        ))}
      </div>
    </>
  );
};

export default ConnectWalletPrompt;
