
import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Download, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface ShareModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  imageUrl: string | null;
}

const ShareModal: React.FC<ShareModalProps> = ({ open, onOpenChange, imageUrl }) => {
  const { toast } = useToast();

  const handleDownload = () => {
    if (imageUrl) {
      const a = document.createElement('a');
      a.href = imageUrl;
      a.download = 'kpop-id-card.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      toast({
        title: "Download Started",
        description: "Your K-POP ID card is downloading",
      });
    }
  };

  const handleShare = (platform: 'warpcast' | 'x') => {
    if (!imageUrl) return;
    
    let url = '';
    const text = 'Check out my K-POP ID card! #BasedKpopID';
    
    if (platform === 'x') {
      url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(window.location.href)}`;
    } else if (platform === 'warpcast') {
      url = `https://warpcast.com/~/compose?text=${encodeURIComponent(text)}`;
    }
    
    window.open(url, '_blank');
    
    toast({
      title: "Sharing",
      description: `Sharing to ${platform === 'x' ? 'X (Twitter)' : 'Warpcast'}`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black/90 border border-gray-700 text-white p-0 max-w-sm mx-auto rounded-lg">
        <div className="relative p-4">
          <button 
            onClick={() => onOpenChange(false)}
            className="absolute right-4 top-4 text-gray-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
          
          <div className="flex flex-col items-center space-y-4 pt-8">
            <div className="flex space-x-8 mt-4">
              <button
                onClick={() => handleShare('warpcast')}
                className="flex flex-col items-center justify-center rounded-full bg-[#6C47FF] h-14 w-14 text-white hover:opacity-90 transition-all"
                aria-label="Share to Warpcast"
              >
                <span className="text-xl font-bold">W</span>
                <span className="text-[8px] mt-1">WARPCAST</span>
              </button>
              
              <button
                onClick={() => handleShare('x')}
                className="flex flex-col items-center justify-center rounded-full bg-black border border-gray-700 h-14 w-14 text-white hover:opacity-90 transition-all"
                aria-label="Share to X"
              >
                <span className="text-xl font-bold">X</span>
                <span className="text-[8px] mt-1">X</span>
              </button>
              
              <button
                onClick={handleDownload}
                className="flex flex-col items-center justify-center rounded-full bg-white h-14 w-14 text-black hover:opacity-90 transition-all"
                aria-label="Download image"
              >
                <Download size={20} />
                <span className="text-[8px] mt-1">DOWNLOAD</span>
              </button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ShareModal;
