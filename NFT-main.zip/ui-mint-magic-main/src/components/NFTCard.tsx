
import React from 'react';
import MetallicFrame from './MetallicFrame';

interface NFTCardProps {
  nft: {
    id?: string;
    name: string;
    mbti: string;
    image_url?: string;
    created_at: string;
  };
}

const NFTCard: React.FC<NFTCardProps> = ({ nft }) => {
  return (
    <div className="flex flex-col">
      <MetallicFrame>
        <div className="bg-kpop-bg-dark p-3 rounded">
          {nft.image_url ? (
            <div className="aspect-[3/4] overflow-hidden rounded mb-2">
              <img 
                src={nft.image_url} 
                alt={nft.name}
                className="w-full h-full object-cover" 
              />
            </div>
          ) : (
            <div className="aspect-[3/4] bg-black/30 flex items-center justify-center rounded mb-2">
              <span className="text-kpop-metallic-dark">No Image</span>
            </div>
          )}
          
          <div className="text-sm">
            <div className="font-mono text-kpop-metallic mb-1">■ NAME: <span className="text-white">{nft.name}</span></div>
            <div className="font-mono text-kpop-metallic mb-1">■ MBTI: <span className="text-white">{nft.mbti}</span></div>
            <div className="font-mono text-kpop-metallic text-xs mb-1">
              ■ MINTED: <span className="text-white">{new Date(nft.created_at).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </MetallicFrame>
    </div>
  );
};

export default NFTCard;
