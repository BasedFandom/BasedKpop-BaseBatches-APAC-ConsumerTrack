
import React from 'react';
import WalletConnect from '@/components/WalletConnect';
import GradientButton from '@/components/GradientButton';
import LoadingDots from '@/components/LoadingDots';

interface WalletSectionProps {
  walletConnected: boolean;
  minted: boolean;
  minting: boolean;
  onMint: () => void;
  onShare: () => void;
  onWalletConnect: () => void;
}

const WalletSection: React.FC<WalletSectionProps> = ({ 
  walletConnected, 
  minted, 
  minting, 
  onMint, 
  onShare, 
  onWalletConnect 
}) => {
  return (
    <div className="mt-8 w-full max-w-xs">
      {!walletConnected && !minted ? (
        <div className="mb-4">
          <WalletConnect onConnect={onWalletConnect} />
        </div>
      ) : null}
      
      {!minted ? (
        <GradientButton 
          onClick={onMint}
          disabled={minting}
          className="w-full"
          variant="mint"
        >
          {minting ? (
            <div className="flex items-center justify-center">
              <span>MINTING</span>
              <LoadingDots className="ml-2" />
            </div>
          ) : (
            walletConnected ? 'MINT WITH PAYMENT (7 USDC)' : 'MINT (FREE DEMO)'
          )}
        </GradientButton>
      ) : (
        <GradientButton 
          onClick={onShare}
          className="w-full"
          variant="turquoise"
        >
          NOW SHOW IT !
        </GradientButton>
      )}
    </div>
  );
};

export default WalletSection;
