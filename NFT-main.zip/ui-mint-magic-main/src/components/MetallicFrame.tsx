
import React, { ReactNode } from 'react';
import { cn } from "@/lib/utils";

interface MetallicFrameProps {
  children: ReactNode;
  className?: string;
}

const MetallicFrame: React.FC<MetallicFrameProps> = ({ children, className }) => {
  return (
    <div className={cn(
      "relative", 
      className
    )}>
      {/* Metallic frame border with corners */}
      <div className="relative border-8 border-[#c0c0c0] bg-gradient-to-b from-[#e0e0e0] via-[#c0c0c0] to-[#a0a0a0] rounded-lg overflow-hidden shadow-2xl">
        {/* Corner pieces - top left */}
        <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-[#e0e0e0] rounded-tl-lg rotate-[-2deg]"></div>
        {/* Corner pieces - top right */}
        <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-[#e0e0e0] rounded-tr-lg rotate-[2deg]"></div>
        {/* Corner pieces - bottom left */}
        <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-[#909090] rounded-bl-lg rotate-[2deg]"></div>
        {/* Corner pieces - bottom right */}
        <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-[#909090] rounded-br-lg rotate-[-2deg]"></div>
        
        {/* Metallic texture/sheen */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-50"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-white/5"></div>
        
        {/* Main content area */}
        <div className="relative w-full h-full bg-gradient-to-b from-[#d0d0d0] to-[#b0b0b0] p-2 rounded-sm">
          {children}
        </div>
      </div>
    </div>
  );
};

export default MetallicFrame;
