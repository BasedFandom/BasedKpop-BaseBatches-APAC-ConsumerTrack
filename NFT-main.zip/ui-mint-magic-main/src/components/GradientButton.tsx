
import React, { ButtonHTMLAttributes } from 'react';
import { cn } from "@/lib/utils";

interface GradientButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'mint' | 'turquoise';
}

const GradientButton: React.FC<GradientButtonProps> = ({ 
  children, 
  className,
  variant = 'default',
  ...props 
}) => {
  const baseClasses = "relative font-mono uppercase tracking-widest py-2.5 px-12 rounded-full transition-all duration-300 text-center";
  
  const variantClasses = {
    default: "bg-gradient-to-r from-[#75fff4] to-[#75cfff] text-[#003d47] font-bold shadow-[0_0_15px_rgba(117,255,244,0.5)] hover:shadow-[0_0_20px_rgba(117,255,244,0.7)]",
    mint: "bg-gradient-to-r from-[#ff75c8] to-[#ff9dff] text-white font-bold shadow-[0_0_15px_rgba(255,117,200,0.5)] hover:shadow-[0_0_20px_rgba(255,117,200,0.7)]",
    turquoise: "bg-gradient-to-r from-[#75fff4] to-[#75cfff] text-[#003d47] font-bold shadow-[0_0_15px_rgba(117,255,244,0.5)] hover:shadow-[0_0_20px_rgba(117,255,244,0.7)]"
  };
  
  return (
    <button 
      className={cn(baseClasses, variantClasses[variant], className)}
      {...props}
    >
      <span className="relative z-10">{children}</span>
    </button>
  );
};

export default GradientButton;
