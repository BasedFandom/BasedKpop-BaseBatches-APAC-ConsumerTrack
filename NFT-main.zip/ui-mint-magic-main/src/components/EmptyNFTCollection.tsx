
import React from 'react';

const EmptyNFTCollection: React.FC = () => {
  return (
    <div className="text-center p-8 border border-kpop-metallic rounded-md">
      <div className="text-xl font-display tracking-widest mb-2">NO MINTED NFTS YET</div>
      <p className="text-kpop-metallic-dark text-sm">
        Create and mint your first KPOP ID card to see it here
      </p>
    </div>
  );
};

export default EmptyNFTCollection;
