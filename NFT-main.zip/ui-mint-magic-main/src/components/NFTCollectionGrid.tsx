
import React from 'react';
import NFTCard from './NFTCard';

interface NFTCollectionGridProps {
  nfts: Array<any>;
  walletAddress?: string;
}

const NFTCollectionGrid: React.FC<NFTCollectionGridProps> = ({ nfts, walletAddress }) => {
  return (
    <div className="py-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-display tracking-widest text-center">YOUR NFT COLLECTION</h2>
        {walletAddress && (
          <div className="wallet-status">
            <span className="text-xs text-kpop-metallic">
              {`${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`}
            </span>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {nfts.map((nft, index) => (
          <NFTCard key={index} nft={nft} />
        ))}
      </div>
    </div>
  );
};

export default NFTCollectionGrid;
