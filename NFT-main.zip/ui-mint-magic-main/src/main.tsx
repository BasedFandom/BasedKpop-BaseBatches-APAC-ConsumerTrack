
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { ThirdwebProvider, embeddedWallet } from "thirdweb/react";
import { client } from "./integrations/thirdweb/client";

// Create provider with appropriate configuration for Thirdweb v5
createRoot(document.getElementById("root")!).render(
  <ThirdwebProvider 
    supportedWallets={[embeddedWallet()]}
    clientId={import.meta.env.VITE_THIRDWEB_CLIENT_ID || "YOUR_CLIENT_ID"}
  >
    <App />
  </ThirdwebProvider>
);
