import { useState, useEffect, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { KpopIdData, NftMint } from '@/types/nft';

// Local storage keys
const ID_DATA_KEY = 'kpop_id_data';
const MINTED_NFTS_KEY = 'kpop_minted_nfts';

export const useKpopId = () => {
  const { toast } = useToast();
  
  // State for the ID card data
  const [idData, setIdData] = useState<KpopIdData | null>(() => {
    const savedData = localStorage.getItem(ID_DATA_KEY);
    return savedData ? JSON.parse(savedData) : null;
  });
  
  // State for minting process
  const [minting, setMinting] = useState(false);
  const [minted, setMinted] = useState(false);
  const [loading, setLoading] = useState(true);
  
  // State for minted NFTs
  const [mintedNfts, setMintedNfts] = useState<NftMint[]>(() => {
    const savedNfts = localStorage.getItem(MINTED_NFTS_KEY);
    return savedNfts ? JSON.parse(savedNfts) : [];
  });

  // Save ID data to local storage when it changes
  useEffect(() => {
    if (idData) {
      localStorage.setItem(ID_DATA_KEY, JSON.stringify(idData));
    }
  }, [idData]);
  
  // Save minted NFTs to local storage when they change
  useEffect(() => {
    localStorage.setItem(MINTED_NFTS_KEY, JSON.stringify(mintedNfts));
  }, [mintedNfts]);

  // Save the ID card data
  const saveIdData = useCallback((data: KpopIdData) => {
    setIdData(data);
    setMinted(false);
  }, []);

  // Mint the ID card as an NFT
  const mintIdCard = useCallback(async (imageUrl: string) => {
    if (!idData) {
      toast({
        title: "No ID Card Data",
        description: "Please create your ID card first",
        variant: "destructive",
      });
      return false;
    }

    try {
      setMinting(true);
      
      // Simulate minting delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Create a mock NFT mint record
      const newNft: NftMint = {
        id: Date.now().toString(),
        user_id: 'mock-user-id',
        name: idData.name,
        mbti: idData.mbti,
        birthday: idData.birthday,
        bias: idData.bias,
        image_url: imageUrl,
        status: 'minted',
        created_at: new Date().toISOString()
      };
      
      // Add the new NFT to the minted NFTs
      setMintedNfts(prev => [newNft, ...prev]);
      
      // Set minted to true
      setMinted(true);
      
      toast({
        title: "Minted Successfully",
        description: "Your K-POP ID card has been minted!",
      });
      
      return true;
    } catch (error) {
      console.error('Error minting ID card:', error);
      toast({
        title: "Minting Failed",
        description: "There was an error minting your ID card. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setMinting(false);
    }
  }, [idData, toast]);

  // Fetch minted NFTs (mocked for now)
  const fetchMintedNfts = useCallback(async () => {
    setLoading(true);
    try {
      // We're using local storage for now, so no need for an actual fetch
      // In a real implementation, this would be an API call
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network delay
      const savedNfts = localStorage.getItem(MINTED_NFTS_KEY);
      const nfts = savedNfts ? JSON.parse(savedNfts) : [];
      return nfts;
    } finally {
      setLoading(false);
    }
  }, []);

  // Initialize loading state
  useEffect(() => {
    const initializeData = async () => {
      await fetchMintedNfts();
    };
    initializeData();
  }, [fetchMintedNfts]);

  return {
    idData,
    saveIdData,
    minting,
    minted,
    loading,
    mintIdCard,
    mintedNfts,
    fetchMintedNfts
  };
};
